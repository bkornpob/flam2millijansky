# flam2millijansky
flam2millijansky converts spectral profile from flam (i.e., erg/s/cm**2/A) to mJy (i.e., 1e-26 erg/s/cm**2/Hz).
